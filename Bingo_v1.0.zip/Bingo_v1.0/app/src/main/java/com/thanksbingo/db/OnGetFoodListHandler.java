package com.thanksbingo.db;

import java.util.ArrayList;

/**
 * Created by hagyut on 2015-02-11.
 */
public interface OnGetFoodListHandler {

    public void onGetFoodList(ArrayList<OtherClasses.SomeFood> food_list);
}
