package com.thanksbingo.db;

import java.util.Date;

/**
 * Created by Hagyut on 2015. 1. 29..
 */
public final class OtherClasses {

    public OtherClasses() {}

    public static class SomeFood {

        public int food_id;
        public String food_name;
        public long frequency;
    }
}
