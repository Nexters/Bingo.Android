package com.devsmart.android.activity;

public interface NavigationDelegate {

	public void onNavigateBack();
	
}